// 主程序
(function () {
    var map = document.getElementById("map");
    var game = new Game(map);
    game.start();
})();
